from devicesave import devicesave
ds = devicesave()
import time

devices = "devicelist.txt"  # can also input a list, e.g. ["L:GR1LO","L:Q01","L:Q03",]
event = "e,0a"              # must be in this format. periodic is acceptable
timer = 5                   # seconds for data to be recorded.
savepath = str(round(time.time()))+"_AcceleratorBaseline"

ds.devicefetch(devices,event,timer,savepath)
