Notes on the program: 

- The devicesave module is a lighter, AcSys Python based alternative to the Java Linac Device Save. It collects data on the specified event or periodicity from the given devices for a time-based duration. It will collect both reading and setting information, when applicable.
- Beam must be enabled before the program is run. 
- Currently there is no "number of readings" based counter or a description of how many readings contributed to the average and standard deviation recorded. These functionalities can be added on request. 

Files in the ZIP: 
- test.py is an example of how to call the program & the inputs you need to provide. 
	devices can be a text file with the format shown in "devicelist.txt" or it can be a list of parameter strings
	event should be a string that is appended after the @ in the AcSys format. It can be event or periodic.
	timer is a int or float that specifies how long data collection should last for in seconds.
	savepath is a string path and/or name for the saved file. 
- devicelist.txt is an example of a text file input for a list of parameters to record. You do not need to specify different parameters for reading and setting; if available, setting will be automatically recorded. 
- devicesave.py contain the class that should be imported. 

Updated 22 April 2025. 




